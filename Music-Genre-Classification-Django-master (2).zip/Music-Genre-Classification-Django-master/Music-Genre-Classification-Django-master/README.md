# Music Genre Classification Django
 Django website for predicting Genre of Music by using Machine Learning Model.
 
# Working of website:
* You need to upload the .wav music file in order to predict the genre of that file.
* If the file is not .wav file then it will show an error.
* If the file is .wav format then within 30 seconds our model will predict the genre of the music file that you uploaded and show it to you.

## Enjoy.
